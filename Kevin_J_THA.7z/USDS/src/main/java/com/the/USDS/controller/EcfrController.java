package com.the.USDS.controller;

import com.the.USDS.entity.EcfrFullXml;
import com.the.USDS.service.EcfrService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/ecfr")
public class EcfrController {

    private final EcfrService service;

    public EcfrController(EcfrService service) { this.service = service; }

    @PostMapping("/download")
    @ResponseBody
    public String download(@RequestParam String date) {
        service.downloadAllTitlesForDate(LocalDate.parse(date));
        return "Download started for " + date;
    }

    @GetMapping("/analysis")
    public String analyze(@RequestParam(required = false) String date, Model model) {
        LocalDate d = (date != null) ? LocalDate.parse(date) : LocalDate.now();

        Map<Integer, EcfrFullXml> metrics = service.getMetricsForDate(d);
        Map<Integer, List<EcfrFullXml>> history = service.getHistoricalChangesPerTitle();

        model.addAttribute("metrics", metrics);
        model.addAttribute("history", history);
        model.addAttribute("selectedDate", d);
        return "analysis";
    }
}