package com.the.USDS.service;

import com.the.USDS.entity.EcfrFullXml;
import com.the.USDS.entity.EcfrStructureJson;
import com.the.USDS.entity.EcfrVersionsJson;
import com.the.USDS.repository.EcfrFullXmlRepository;
import com.the.USDS.repository.EcfrStructureJsonRepository;
import com.the.USDS.repository.EcfrVersionsJsonRepository;
import org.springframework.stereotype.Service;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDate;
import java.util.*;

@Service
public class EcfrService {

    private final EcfrFullXmlRepository xmlRepo;
    private final EcfrStructureJsonRepository structureRepo;
    private final EcfrVersionsJsonRepository versionsRepo;

    public EcfrService(EcfrFullXmlRepository xmlRepo,
                       EcfrStructureJsonRepository structureRepo,
                       EcfrVersionsJsonRepository versionsRepo) {
        this.xmlRepo = xmlRepo;
        this.structureRepo = structureRepo;
        this.versionsRepo = versionsRepo;
    }

    public void downloadAllTitlesForDate(LocalDate date) {
        for (int title = 1; title <= 5; title++) {
            try {
                getXML(date, title);
                byTitleNumberAndDate(date, title);
                byTitleNumber(title);
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            } catch (ParserConfigurationException e) {
                throw new RuntimeException(e);
            } catch (SAXException e) {
                throw new RuntimeException(e);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    private void byTitleNumber(int title) throws IOException {
        if (!versionsRepo.existsByTitleNumber(title)) {
            String versionsUrl = String.format(
                    "https://www.ecfr.gov/api/versioner/v1/versions/title-%d.json",
                    title);
            String versionsJson = new String(new URL(versionsUrl).openStream().readAllBytes(), StandardCharsets.UTF_8);
            versionsRepo.save(new EcfrVersionsJson(title, versionsJson));
        }
    }

    private void byTitleNumberAndDate(LocalDate date, int title) throws IOException {
        if (!structureRepo.existsByTitleNumberAndDate(title, date)) {
            String structureUrl = String.format(
                    "https://www.ecfr.gov/api/versioner/v1/structure/%s/title-%d.json",
                    date, title);
            String structureJson = new String(new URL(structureUrl).openStream().readAllBytes(), StandardCharsets.UTF_8);
            structureRepo.save(new EcfrStructureJson(title, date, structureJson));
        }
    }

    private void getXML(LocalDate date, int title) throws Exception {
        if (!xmlRepo.existsByTitleNumberAndDate(title, date)) {
            String xmlUrl = String.format(
                    "https://www.ecfr.gov/api/versioner/v1/full/%s/title-%d.xml",
                    date, title);
            Document doc = DocumentBuilderFactory.newInstance()
                    .newDocumentBuilder()
                    .parse(new URL(xmlUrl).openStream());
            doc.getDocumentElement().normalize();
            String xmlText = extractText(doc.getDocumentElement());
            int wordCount = xmlText.split("\\s+").length;
            String checksum = sha256(xmlText);
            xmlRepo.save(new EcfrFullXml(title, date, xmlText, wordCount, checksum));
        }
    }

    private String extractText(Node node) {
        StringBuilder sb = new StringBuilder();
        if (node.getNodeType() == Node.TEXT_NODE) sb.append(node.getTextContent()).append(" ");
        NodeList children = node.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) sb.append(extractText(children.item(i)));
        return sb.toString();
    }

    private String sha256(String text) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(text.getBytes(StandardCharsets.UTF_8));
        StringBuilder hex = new StringBuilder();
        for (byte b : hash) hex.append(String.format("%02x", b));
        return hex.toString();
    }

    public Map<Integer, EcfrFullXml> getMetricsForDate(LocalDate date) {
        List<EcfrFullXml> list = xmlRepo.findByDate(date);
        Map<Integer, EcfrFullXml> map = new TreeMap<>();
        for (EcfrFullXml ecfrFullXml : list) map.put(ecfrFullXml.getTitleNumber(), ecfrFullXml);
        return map;
    }

    public Map<Integer, List<EcfrFullXml>> getHistoricalChangesPerTitle() {
        Map<Integer, List<EcfrFullXml>> map = new TreeMap<>();
        for (EcfrFullXml ecfrFullXml : xmlRepo.findAll()) {
            map.computeIfAbsent(ecfrFullXml.getTitleNumber(), k -> new ArrayList<>()).add(ecfrFullXml);
        }
        map.values().forEach(list -> list.sort(Comparator.comparing(EcfrFullXml::getDate)));
        return map;
    }
}