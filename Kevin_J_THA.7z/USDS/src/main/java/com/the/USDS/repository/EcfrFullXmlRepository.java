package com.the.USDS.repository;

import com.the.USDS.entity.EcfrFullXml;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface EcfrFullXmlRepository extends JpaRepository<EcfrFullXml, Long> {
    boolean existsByTitleNumberAndDate(int titleNumber, LocalDate date);
    List<EcfrFullXml> findByDate(LocalDate date);
}