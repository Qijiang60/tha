package com.the.USDS.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Entity
@Data
@AllArgsConstructor
@Builder
@Table(name = "ecfr_versions_json")
public class EcfrVersionsJson {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int titleNumber;

    @Lob
    private String jsonContent;

    public EcfrVersionsJson() {}
    public EcfrVersionsJson(int titleNumber, String jsonContent) {
        this.titleNumber = titleNumber;
        this.jsonContent = jsonContent;
    }

}
