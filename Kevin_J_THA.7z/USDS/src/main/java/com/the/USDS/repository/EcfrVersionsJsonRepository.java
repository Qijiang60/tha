package com.the.USDS.repository;

import com.the.USDS.entity.EcfrVersionsJson;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EcfrVersionsJsonRepository extends JpaRepository<EcfrVersionsJson, Long> {
    boolean existsByTitleNumber(int titleNumber);
}
