package com.the.USDS.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Entity
@Data
@AllArgsConstructor
@Builder
@Table(name = "ecfr_structure_json")
public class EcfrStructureJson {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int titleNumber;
    private LocalDate date;

    @Lob
    private String jsonContent;

    public EcfrStructureJson() {}
    public EcfrStructureJson(int titleNumber, LocalDate date, String jsonContent) {
        this.titleNumber = titleNumber;
        this.date = date;
        this.jsonContent = jsonContent;
    }
}
