package com.the.USDS.repository;

import com.the.USDS.entity.EcfrStructureJson;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;

public interface EcfrStructureJsonRepository extends JpaRepository<EcfrStructureJson, Long> {
    boolean existsByTitleNumberAndDate(int titleNumber, LocalDate date);
}
