package com.the.USDS.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Data
@AllArgsConstructor
@Builder
@Table(name = "ecfr_full_xml")
public class EcfrFullXml {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int titleNumber;
    private LocalDate date;

    @Lob
    private String xmlContent;

    private int wordCount;
    private String checksum;

    public EcfrFullXml() {}
    public EcfrFullXml(int titleNumber, LocalDate date, String xmlContent, int wordCount, String checksum) {
        this.titleNumber = titleNumber;
        this.date = date;
        this.xmlContent = xmlContent;
        this.wordCount = wordCount;
        this.checksum = checksum;
    }

}